package com.syne.asn.auth.domain;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class CustomUserDetails extends Users implements UserDetails {
	
	
	 /**
	 * @author hidayath
	 */
	private static final long serialVersionUID = 1L;
	
	

	public CustomUserDetails(final Users users) {
	        super(users);
	    }
	
	   /*Collection<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
       grantedAuthorities.add(new SimpleGrantedAuthority("USER"));
         for (Role role : account.getRoles()) {
           grantedAuthorities.add(new SimpleGrantedAuthority(role.getCode()));
       }


	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		
		 return getRoles()
	                .stream()
	                .map(role -> new SimpleGrantedAuthority(("USER")))
	                .collect(Collectors.toList());
		//return null;
	}*/

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return null;
	}

}
