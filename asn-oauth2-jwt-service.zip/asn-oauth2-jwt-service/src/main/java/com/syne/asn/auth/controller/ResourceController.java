package com.syne.asn.auth.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.syne.asn.auth.domain.AuthToken;
import com.syne.asn.auth.domain.LoginUser;
import com.syne.asn.auth.domain.Users;
import com.syne.asn.auth.service.GenericService;

/**
 * Created by hidayath
 */
@RestController
//@RequestMapping("/asnauth")
public class ResourceController {

	@Autowired
	private GenericService userService;

	@Autowired
	private AuthenticationManager authenticationManager;

	/*@Autowired
	private TokenProvider jwtTokenUtil;*/
	
	@Value("${security.jwt.client-id}")
	private String clientId;

	@Value("${security.jwt.client-secret}")
	private String clientSecret;

	@Value("${security.jwt.grant-type}")
	private String grantType;

	@Value("${security.jwt.scope-read}")
	private String scopeRead;
	/**
	 * Create a new user account
	 * 
	 * @param account user account
	 * @return created account as json
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Users> register(@Valid @RequestBody Users account, BindingResult errors) {

		// Check if account is unique
		if (errors.hasErrors()) {
			throw new InvalidRequestException("Username already exists");
		}

		Users createdAccount = userService.createNewAccount(account);
		return new ResponseEntity<Users>(createdAccount, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/users", method = RequestMethod.GET)
	// @PreAuthorize("hasAuthority('ADMIN_USER')")
	public List<Users> getUsers() {
		return userService.findAllUsers();
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity checkUserDetails(@RequestBody LoginUser loginUser,HttpServletRequest req) throws AuthenticationException {
		
		final Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginUser.getUsername(), loginUser.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		StringBuffer sb = req.getRequestURL();
		final String url = sb.toString().replace("login", "oauth/token");
		OAuth2AccessToken token = generateTokenAccess(url, loginUser); 
		System.out.println("token:: " + token);
		return ResponseEntity.ok(new AuthToken(token.getValue()));
	}
	
	public OAuth2AccessToken generateTokenAccess(String url, LoginUser loginUser) {

		ResourceOwnerPasswordResourceDetails resourceDetails = new ResourceOwnerPasswordResourceDetails();
		resourceDetails.setUsername(loginUser.getUsername());
		resourceDetails.setPassword(loginUser.getPassword());
		resourceDetails.setAccessTokenUri(url);
		resourceDetails.setClientId(clientId);
		resourceDetails.setClientSecret(clientSecret);
		resourceDetails.setGrantType("password");
		resourceDetails.setScope(Arrays.asList("read"));

		DefaultOAuth2ClientContext clientContext = new DefaultOAuth2ClientContext();

		OAuth2RestTemplate restTemplate = new OAuth2RestTemplate(resourceDetails, clientContext);
		restTemplate.setMessageConverters(Arrays.asList(new MappingJackson2HttpMessageConverter()));

		OAuth2AccessToken token = restTemplate.getAccessToken();

		return token;

	}

}
