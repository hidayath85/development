package com.syne.asn.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.syne.asn.auth.domain.Users;


@Repository
public interface UserRepository extends JpaRepository<Users, Long> {
   
	Users findByUsername(String username);
    
    /**
     * Query for a single Account entity by username.
     *
     * @param username A String username value to query the repository.
     * @return An Account or <code>null</code> if none found.
     */
   // @Query("SELECT a FROM USERS a WHERE a.username = :username")
   // Users findByUsername(@Param("username") String username);
}
