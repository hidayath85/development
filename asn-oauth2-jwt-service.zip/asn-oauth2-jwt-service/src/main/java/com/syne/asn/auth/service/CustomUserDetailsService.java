package com.syne.asn.auth.service;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.syne.asn.auth.domain.Users;
import com.syne.asn.auth.repository.UserRepository;



@Service
public class CustomUserDetailsService implements UserDetailsService {
	
	@Autowired
	private  UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		
	/*	//Users accUser = userRepository.findByUsername(username);
		
		
		 Optional<Users> usersOptional = userRepository.findByUsername(username);

	        usersOptional
	                .orElseThrow(() -> new UsernameNotFoundException("Username not found!"));
	    
	        return usersOptional
	                .map(CustomUserDetails::new)
	                .get();*/

      /*  if (accUser == null) {
            // Not found...
            throw new UsernameNotFoundException(
                    "User " + username + " not found.");
        }

        if (accUser.getRoles() == null || account.getRoles().isEmpty()) {
            // No Roles assigned to user...
            throw new UsernameNotFoundException("User not authorized.");
        }


        Collection<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
        grantedAuthorities.add(new SimpleGrantedAuthority("USER"));
          for (Role role : account.getRoles()) {
            grantedAuthorities.add(new SimpleGrantedAuthority(role.getCode()));
        }

        User userDetails = new User(accUser.getUsername(),
        		accUser.getFirstName(),accUser.getLastName(),
        		accUser.getEmail(),accUser.getPassword(), accUser.isEnabled(),
                !accUser.isExpired(), !accUser.isCredentialsexpired(),
                !accUser.isLocked(), grantedAuthorities);

        return userDetails;*/
	        
	        
	        
	        

			Users accUser = userRepository.findByUsername(username);

	        if (accUser == null) {
	            // Not found...
	            throw new UsernameNotFoundException(
	                    "User " + username + " not found.");
	        }

	       /* if (accUser.getRoles() == null || account.getRoles().isEmpty()) {
	            // No Roles assigned to user...
	            throw new UsernameNotFoundException("User not authorized.");
	        }*/


	        Collection<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
	        grantedAuthorities.add(new SimpleGrantedAuthority("USER"));
	        /*  for (Role role : account.getRoles()) {
	            grantedAuthorities.add(new SimpleGrantedAuthority(role.getCode()));
	        }*/

	        User userDetails = new User(accUser.getUsername(),
	        		accUser.getPassword(), accUser.isEnabled(),
	                !accUser.isExpired(), !accUser.isCredentialsexpired(),
	                !accUser.isLocked(), grantedAuthorities);

	        return userDetails;
	}

}
