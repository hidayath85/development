package com.syne.asn.auth.service;

import java.util.List;

import com.syne.asn.auth.domain.Users;


public interface GenericService {
	
    Users findByUsername(String username);
    
    Users createNewAccount(Users account);

    List<Users> findAllUsers();
}
